import numpy as np
import matplotlib.pyplot as plt
import scienceplots

plt.style.use(['science', 'notebook', 'grid'])

# =============================================================================
# Generando la red de átomos
# =============================================================================

Nx, Ny, Nz = 20,20,20
Natom = Nx*Ny*Nz
pos1 = []
base = np.array([0,0,0])
for i in range(Nx):
    for j in range(Ny):
        for k in range(Nz):
            pos1.append([i+base[0],j+base[1],k+base[2]])

pos = np.array(pos1)

# Parámetros
tau = 8 * 24 * 60   # Periodo de semidesintegración en minutos
T = 80 * 24 * 60  # Tiempo total de la simulación en minutos
dt = 180  # Paso de tiempo en minutos

# Inicialización de las listas para guardar los resultados
t = np.arange(0, T, dt)
N_I131 = np.zeros_like(t)
N_Xe131 = np.zeros_like(t) #Xenon-131 en el estado fundamental
N_Xe131_I = np.zeros_like(t) #Xenon-131 en el primer estado excitado
N_Xe131_II = np.zeros_like(t) #Xenon-131 en el segundo estado excitado
N_I131[0] = Natom

atoms = np.zeros_like(pos[:,0])
accel = 1
atoms_t = np.zeros([int(T/(dt*accel)),len(pos[:,0])])
energy = np.zeros_like(t)


for i in range(1,t.size):
    s = np.random.random(atoms.size)
    #Vemos si se desintegra o no
    
    indices_comunes = (atoms == 0) * (s < 1-2**(-dt/tau))
    atoms[indices_comunes] = 1
    
    #Vemos si es por el camino 1 o por el camino 2
    
    r = np.random.random(atoms.size)
    indices_comunes1 = (atoms == 1) * (r < 0.899)
    atoms[indices_comunes1] = 2
    energy[i-1] =  np.sum(atoms == 1) * 334 + np.sum([atoms == 2]) * 606
    N_Xe131_I[i-1] = np.sum(atoms == 2)
    N_Xe131_II[i-1] = np.sum(atoms == 1)
    
    
    atoms[np.where(atoms == 1)[0]],atoms[np.where(atoms == 2)[0]] = 3,3
    N_I131[i] = np.sum(atoms == 0)
    N_Xe131[i] = np.sum(atoms == 3)
    
    
    if i%accel == 0:
        atoms_t[i] = atoms


#Graficamos la energía liberada en cada paso de tiempo
plt.figure()
plt.plot(t / (60*24), energy/1000)
plt.xlabel('t(días)')
plt.ylabel('E(MeV)')
plt.title('Energía liberada')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t / (60*24), np.cumsum(energy)/1000)
plt.xlabel('t(días)')
plt.ylabel('E(MeV)')
plt.title('Energía acumulada liberada')
plt.tight_layout()
plt.show()

#Graficamos las poblaciones de cada uno de los átomos
plt.figure()
plt.plot(t/(60 * 24), N_I131, label = 'Nº de atomos de I')
plt.plot(t/ (60 * 24), N_Xe131, label = 'Nº de atomos de Xe')
plt.xlabel('t(días)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t/(60 * 24), N_Xe131_I, label = 'Nº de atomos de Xe*')
plt.plot(t/ (60 * 24), N_Xe131_II, label = 'Nº de atomos de Xe**')
plt.xlabel('t(días)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.title('Nº de desintegraciones por paso de tiempo ')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t/(60 * 24), np.cumsum(N_Xe131_I)/Natom, label = 'Nº de atomos de Xe*')
plt.plot(t/ (60 * 24), np.cumsum(N_Xe131_II)/Natom, label = 'Nº de atomos de Xe**')
plt.xlabel('t(días)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.title('Nº de desintegraciones acumuladas (normalizado) ')
plt.tight_layout()
plt.show()


#Graficamos la red con los átomos que se han desintegrado en un tiempo
fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[8])
plt.title('Número de átomos desintegrados para t = {} días'.format(t[8]/(60 * 24)))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[64])
plt.title('Número de átomos desintegrados para t = {} días'.format(t[64]/(60 * 24)))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[160])
plt.title('Número de átomos desintegrados para t = {} días'.format(t[160]/(60 * 24)))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[-1])
plt.title('Número de átomos desintegrados para t = {} días'.format(round(t[-1]/(60 * 24))))
plt.show()

# =============================================================================
# OTRO ISÓTOPO
# =============================================================================

# Parámetros
tau = 5.27 * 365   # Periodo de semidesintegración en días
T = 50 * 365  # Tiempo total de la simulación en días
dt = 250  # Paso de tiempo en días

# Inicialización de las listas para guardar los resultados
t = np.arange(0, T, dt)
N_Co60 = np.zeros_like(t)
N_Ni60 = np.zeros_like(t) #Ni60 en el estado fundamental
N_Ni60_I = np.zeros_like(t) #Ni60 en el primer estado excitado
N_Ni60_II = np.zeros_like(t) #Ni60 en el segundo estado excitado
N_Co60[0] = Natom

atoms = np.zeros_like(pos[:,0])
accel = 1
atoms_t = np.zeros([int(T/(dt*accel)),len(pos[:,0])])
energy = np.zeros_like(t)


for i in range(1,t.size):
    s = np.random.random(atoms.size)
    #Vemos si se desintegra o no
    
    indices_comunes = (atoms == 0) * (s < 1-2**(-dt/tau))
    atoms[indices_comunes] = 1
    
    #Vemos si es por el camino 1 o por el camino 2
    
    r = np.random.random(atoms.size)
    indices_comunes1 = (atoms == 1) * (r < 0.012)
    atoms[indices_comunes1] = 2
    energy[i-1] =  np.sum(atoms == 1) * 0.31 + np.sum([atoms == 2]) * 1.48 #Teniendo en cuenta únicamente la energía emitida en desintegración beta
    N_Ni60_I[i-1] = np.sum(atoms == 2)
    N_Ni60_II[i-1] = np.sum(atoms == 1)
    
    
    atoms[np.where(atoms == 1)[0]],atoms[np.where(atoms == 2)[0]] = 3,3
    N_Co60[i] = np.sum(atoms == 0)
    N_Ni60[i] = np.sum(atoms == 3)
    
    
    if i%accel == 0:
        atoms_t[i] = atoms


#Graficamos la energía liberada en cada paso de tiempo
plt.figure()
plt.plot(t / 365 , energy)
plt.xlabel('t(años)')
plt.ylabel('E(MeV)')
plt.title('Energía liberada')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t / (365), np.cumsum(energy))
plt.xlabel('t(años)')
plt.ylabel('E(MeV)')
plt.title('Energía acumulada liberada')
plt.tight_layout()
plt.show()

#Graficamos las poblaciones de cada uno de los átomos
plt.figure()
plt.plot(t/(365), N_Co60, label = 'Nº de atomos de Co')
plt.plot(t/ (365), N_Ni60, label = 'Nº de atomos de Ni')
plt.xlabel('t(años)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t/(365), N_Ni60_I, label = 'Nº de atomos de Ni*')
plt.plot(t/ (365), N_Ni60_II, label = 'Nº de atomos de Ni**')
plt.xlabel('t(años)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.title('Nº de desintegraciones por paso de tiempo ')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t/(365), np.cumsum(N_Ni60_I)/Natom, label = 'Nº de atomos de Ni*')
plt.plot(t/ (365), np.cumsum(N_Ni60_II)/Natom, label = 'Nº de atomos de Ni**')
plt.xlabel('t(años)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.title('Nº de desintegraciones acumuladas (normalizado) ')
plt.tight_layout()
plt.show()


#Graficamos la red con los átomos que se han desintegrado en un tiempo
fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[8])
plt.title('Número de átomos desintegrados para t = {} años'.format(round(t[8]/(365))))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[15])
plt.title('Número de átomos desintegrados para t = {} años'.format(round(t[15]/(365))))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[-1])
plt.title('Número de átomos desintegrados para t = {} años'.format(round(t[-1]/(365))))
plt.show()






