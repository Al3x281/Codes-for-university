import numpy as np
import matplotlib.pyplot as plt
import scienceplots

plt.style.use(['science', 'notebook', 'grid'])

#Definimos las constantes
mu_s = 1.07
mu_a = .16
mu_t = mu_s + mu_a

def phot_traj(mu_t,mu_a,mu_s):
    #Definimos la condición inicial
    mu = np.array([0,0,1]).reshape((1,3))
    s = -np.log(np.random.random(1)) / mu_t
    ener = np.array([637]) #keV
    
    while True:
        chi = np.random.random(1)
        s = np.hstack((s, -np.log(np.random.random(1)) / mu_t))
        theta = np.arccos(1-2*chi)
        phi = 2*np.pi*np.random.random(1)
        delta_ener = mu_a/mu_t * ener[-1]
        
        if mu[-1,2] == 1:
            mu_x = np.sin(theta) * np.cos(phi)
            mu_y = np.sin(theta) * np.sin(phi)
            mu_z = np.cos(theta)
            
        elif mu[-1,2] == -1:
            mu_x = np.sin(theta) * np.cos(phi)
            mu_y = -np.sin(theta) * np.sin(phi)
            mu_z = -np.cos(theta)        
            
        else:
            mu_x = (np.sin(theta) * (mu[-1,0]*mu[-1,2] * np.cos(phi) - mu[-1,1]*np.sin(phi)))/(np.sqrt(1-mu[-1,2]**2)) + mu[-1,0] * np.cos(theta)
            mu_y = (np.sin(theta) * (mu[-1,1]*mu[-1,2] * np.cos(phi) + mu[-1,0]*np.sin(phi)))/(np.sqrt(1-mu[-1,2]**2)) + mu[-1,1] * np.cos(theta)
            mu_z = -np.sqrt(1-mu[-1,2]**2) * np.sin(theta) * np.cos(phi) + mu[-1,2] * np.cos(theta)
            
        mu_new = np.array([mu_x,mu_y,mu_z])
        ener = np.hstack((ener, ener[-1] - delta_ener))
        mu = np.vstack((mu, mu_new.T))
        
        if ener[-1] < 1e-10:
            break
    
    pos = np.array([mu[:,0] * s, mu[:,1] * s, mu[:,2] * s])
    return pos, ener

pos, ener = phot_traj(mu_t,mu_a,mu_s)

plt.figure()
plt.plot(ener)
plt.xlabel('Iteraciones')
plt.ylabel('Energía (keV)')
plt.title('Energía del fotón')
plt.title('$\\mu_a = {}$ $\\mu_s = {}$'.format(mu_a,mu_s))
plt.tight_layout()
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
ax.plot(pos[0],pos[1],pos[2])
plt.title('Trayectoria del fotón')
plt.show()


#Calculamos el promedio 

num_int = 50

def media_columnas_saltos_tres(matriz):
    medias_x = []
    medias_y = []
    medias_z = []
    # Iterar sobre las columnas
    for col in range(len(matriz[0])):
        elementos_columna_x = []
        elementos_columna_y = []
        elementos_columna_z = []
        # Iterar sobre las filas x con saltos de tres
        for fila_x in range(0, len(matriz), 3):
            if fila_x < len(matriz):
                elementos_columna_x.append(matriz[fila_x][col])
        # Iterar sobre las filas con saltos de tres
        for fila_y in range(1, len(matriz), 3):
            if fila_y < len(matriz):
                elementos_columna_y.append(matriz[fila_y][col])
        for fila_z in range(2, len(matriz), 3):
            if fila_z < len(matriz):
                elementos_columna_z.append(matriz[fila_z][col])
        # Calcular la media si hay elementos en la columna
        if elementos_columna_x:
            medias_x.append(np.mean(elementos_columna_x))
        if elementos_columna_y:
            medias_y.append(np.mean(elementos_columna_y))
        if elementos_columna_z:
            medias_z.append(np.mean(elementos_columna_z))
        
    return np.array([medias_x,medias_y,medias_z])


def mean_interaction(num_int):
    pos, _ = phot_traj(mu_t,mu_a,mu_s)
    for i in range(num_int):
        pos_new, _ = phot_traj(mu_t,mu_a,mu_s) 
        pos = np.vstack((pos, pos_new))
    
    mean_pos = media_columnas_saltos_tres(pos)
    return mean_pos


mean = mean_interaction(num_int)

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
ax.plot(mean[0],mean[1],mean[2])
plt.title('Promedio interacciones $\\mu_a = {}$ $\\mu_s = {}$'.format(mu_a,mu_s))
plt.show()