import numpy as np
import matplotlib.pyplot as plt
import scienceplots

plt.style.use(['science', 'notebook', 'grid'])

# =============================================================================
# Práctica 1
# =============================================================================

import numpy as np
import matplotlib.pyplot as plt
import scienceplots

plt.style.use(['science', 'notebook', 'grid'])

# =============================================================================
# Generando la red de átomos
# =============================================================================

Nx, Ny, Nz = 5,5,5
Natom = Nx*Ny*Nz
pos1 = []
base = np.array([0,0,0])
for i in range(Nx):
    for j in range(Ny):
        for k in range(Nz):
            pos1.append([i+base[0],j+base[1],k+base[2]])

pos = np.array(pos1)

# Parámetros
tau = 8 * 24 * 60   # Periodo de semidesintegración en minutos
T = 80 * 24 * 60  # Tiempo total de la simulación en minutos
dt = 180  # Paso de tiempo en minutos

# Inicialización de las listas para guardar los resultados
t = np.arange(0, T, dt)
N_I131 = np.zeros_like(t)
N_Xe131 = np.zeros_like(t) #Xenon-131 en el estado fundamental
N_Xe131_I = np.zeros_like(t) #Xenon-131 en el primer estado excitado
N_Xe131_II = np.zeros_like(t) #Xenon-131 en el segundo estado excitado
N_I131[0] = Natom

atoms = np.zeros_like(pos[:,0])
accel = 1
atoms_t = np.zeros([int(T/(dt*accel)),len(pos[:,0])])
energy = np.zeros_like(t)


for i in range(1,t.size):
    s = np.random.random(atoms.size)
    #Vemos si se desintegra o no
    
    indices_comunes = (atoms == 0) * (s < 1-2**(-dt/tau))
    atoms[indices_comunes] = 1
    
    #Vemos si es por el camino 1 o por el camino 2
    
    r = np.random.random(atoms.size)
    indices_comunes1 = (atoms == 1) * (r < 0.899)
    atoms[indices_comunes1] = 2
    energy[i-1] =  np.sum(atoms == 1) * 334 + np.sum([atoms == 2]) * 606
    N_Xe131_I[i-1] = np.sum(atoms == 2)
    N_Xe131_II[i-1] = np.sum(atoms == 1)
    
    
    atoms[np.where(atoms == 1)[0]],atoms[np.where(atoms == 2)[0]] = 3,3
    N_I131[i] = np.sum(atoms == 0)
    N_Xe131[i] = np.sum(atoms == 3)
    
    
    if i%accel == 0:
        atoms_t[i] = atoms


#Graficamos la energía liberada en cada paso de tiempo
plt.figure()
plt.plot(t / (60*24), energy/1000)
plt.xlabel('t(días)')
plt.ylabel('E(MeV)')
plt.title('Energía liberada')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t / (60*24), np.cumsum(energy)/1000)
plt.xlabel('t(días)')
plt.ylabel('E(MeV)')
plt.title('Energía acumulada liberada')
plt.tight_layout()
plt.show()

#Graficamos las poblaciones de cada uno de los átomos
plt.figure()
plt.plot(t/(60 * 24), N_I131, label = 'Nº de atomos de I')
plt.plot(t/ (60 * 24), N_Xe131, label = 'Nº de atomos de Xe')
plt.xlabel('t(días)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t/(60 * 24), N_Xe131_I, label = 'Nº de atomos de Xe*')
plt.plot(t/ (60 * 24), N_Xe131_II, label = 'Nº de atomos de Xe**')
plt.xlabel('t(días)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.title('Nº de desintegraciones por paso de tiempo ')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t/(60 * 24), np.cumsum(N_Xe131_I)/Natom, label = 'Nº de atomos de Xe*')
plt.plot(t/ (60 * 24), np.cumsum(N_Xe131_II)/Natom, label = 'Nº de atomos de Xe**')
plt.xlabel('t(días)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.title('Nº de desintegraciones acumuladas (normalizado) ')
plt.tight_layout()
plt.show()


#Graficamos la red con los átomos que se han desintegrado en un tiempo
fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[8])
plt.title('Número de átomos desintegrados para t = {} días'.format(t[8]/(60 * 24)))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[64])
plt.title('Número de átomos desintegrados para t = {} días'.format(t[64]/(60 * 24)))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[160])
plt.title('Número de átomos desintegrados para t = {} días'.format(t[160]/(60 * 24)))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[-1])
plt.title('Número de átomos desintegrados para t = {} días'.format(round(t[-1]/(60 * 24))))
plt.show()

# =============================================================================
# OTRO ISÓTOPO
# =============================================================================

# Parámetros
tau = 5.27 * 365   # Periodo de semidesintegración en días
T = 50 * 365  # Tiempo total de la simulación en días
dt = 250  # Paso de tiempo en días

# Inicialización de las listas para guardar los resultados
t = np.arange(0, T, dt)
N_Co60 = np.zeros_like(t)
N_Ni60 = np.zeros_like(t) #Ni60 en el estado fundamental
N_Ni60_I = np.zeros_like(t) #Ni60 en el primer estado excitado
N_Ni60_II = np.zeros_like(t) #Ni60 en el segundo estado excitado
N_Co60[0] = Natom

atoms = np.zeros_like(pos[:,0])
accel = 1
atoms_t = np.zeros([int(T/(dt*accel)),len(pos[:,0])])
energy = np.zeros_like(t)


for i in range(1,t.size):
    s = np.random.random(atoms.size)
    #Vemos si se desintegra o no
    
    indices_comunes = (atoms == 0) * (s < 1-2**(-dt/tau))
    atoms[indices_comunes] = 1
    
    #Vemos si es por el camino 1 o por el camino 2
    
    r = np.random.random(atoms.size)
    indices_comunes1 = (atoms == 1) * (r < 0.012)
    atoms[indices_comunes1] = 2
    energy[i-1] =  np.sum(atoms == 1) * 0.31 + np.sum([atoms == 2]) * 1.48 #Teniendo en cuenta únicamente la energía emitida en desintegración beta
    N_Ni60_I[i-1] = np.sum(atoms == 2)
    N_Ni60_II[i-1] = np.sum(atoms == 1)
    
    
    atoms[np.where(atoms == 1)[0]],atoms[np.where(atoms == 2)[0]] = 3,3
    N_Co60[i] = np.sum(atoms == 0)
    N_Ni60[i] = np.sum(atoms == 3)
    
    
    if i%accel == 0:
        atoms_t[i] = atoms


#Graficamos la energía liberada en cada paso de tiempo
plt.figure()
plt.plot(t / 365 , energy)
plt.xlabel('t(años)')
plt.ylabel('E(MeV)')
plt.title('Energía liberada')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t / (365), np.cumsum(energy))
plt.xlabel('t(años)')
plt.ylabel('E(MeV)')
plt.title('Energía acumulada liberada')
plt.tight_layout()
plt.show()

#Graficamos las poblaciones de cada uno de los átomos
plt.figure()
plt.plot(t/(365), N_Co60, label = 'Nº de atomos de Co')
plt.plot(t/ (365), N_Ni60, label = 'Nº de atomos de Ni')
plt.xlabel('t(años)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t/(365), N_Ni60_I, label = 'Nº de atomos de Ni*')
plt.plot(t/ (365), N_Ni60_II, label = 'Nº de atomos de Ni**')
plt.xlabel('t(años)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.title('Nº de desintegraciones por paso de tiempo ')
plt.tight_layout()
plt.show()

plt.figure()
plt.plot(t/(365), np.cumsum(N_Ni60_I)/Natom, label = 'Nº de atomos de Ni*')
plt.plot(t/ (365), np.cumsum(N_Ni60_II)/Natom, label = 'Nº de atomos de Ni**')
plt.xlabel('t(años)')
plt.ylabel('Nº de partículas')
plt.legend(loc = 'best', fontsize = 'large')
plt.title('Nº de desintegraciones acumuladas (normalizado) ')
plt.tight_layout()
plt.show()


#Graficamos la red con los átomos que se han desintegrado en un tiempo
fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[8])
plt.title('Número de átomos desintegrados para t = {} años'.format(round(t[8]/(365))))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[15])
plt.title('Número de átomos desintegrados para t = {} años'.format(round(t[15]/(365))))
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
sc = ax.scatter(pos[:,0], pos[:,1], pos[:,2], c = atoms_t[-1])
plt.title('Número de átomos desintegrados para t = {} años'.format(round(t[-1]/(365))))
plt.show()

# =============================================================================
# Práctica 2
# =============================================================================

#Definimos las constantes
mu_s = 1.07
mu_a = .16
mu_t = mu_s + mu_a

def phot_traj(mu_t,mu_a,mu_s):
    #Definimos la condición inicial
    mu = np.array([0,0,1]).reshape((1,3))
    s = -np.log(np.random.random(1)) / mu_t
    ener = np.array([637]) #keV
    
    while True:
        chi = np.random.random(1)
        s = np.hstack((s, -np.log(np.random.random(1)) / mu_t))
        theta = np.arccos(1-2*chi)
        phi = 2*np.pi*np.random.random(1)
        delta_ener = mu_a/mu_t * ener[-1]
        
        if mu[-1,2] == 1:
            mu_x = np.sin(theta) * np.cos(phi)
            mu_y = np.sin(theta) * np.sin(phi)
            mu_z = np.cos(theta)
            
        elif mu[-1,2] == -1:
            mu_x = np.sin(theta) * np.cos(phi)
            mu_y = -np.sin(theta) * np.sin(phi)
            mu_z = -np.cos(theta)        
            
        else:
            mu_x = (np.sin(theta) * (mu[-1,0]*mu[-1,2] * np.cos(phi) - mu[-1,1]*np.sin(phi)))/(np.sqrt(1-mu[-1,2]**2)) + mu[-1,0] * np.cos(theta)
            mu_y = (np.sin(theta) * (mu[-1,1]*mu[-1,2] * np.cos(phi) + mu[-1,0]*np.sin(phi)))/(np.sqrt(1-mu[-1,2]**2)) + mu[-1,1] * np.cos(theta)
            mu_z = -np.sqrt(1-mu[-1,2]**2) * np.sin(theta) * np.cos(phi) + mu[-1,2] * np.cos(theta)
            
        mu_new = np.array([mu_x,mu_y,mu_z])
        ener = np.hstack((ener, ener[-1] - delta_ener))
        mu = np.vstack((mu, mu_new.T))
        
        if ener[-1] < 1e-10:
            break
    
    pos = np.array([mu[:,0] * s, mu[:,1] * s, mu[:,2] * s])
    return pos, ener

pos, ener = phot_traj(mu_t,mu_a,mu_s)

plt.figure()
plt.plot(ener)
plt.xlabel('Iteraciones')
plt.ylabel('Energía (keV)')
plt.title('Energía del fotón')
plt.title('$\\mu_a = {}$ $\\mu_s = {}$'.format(mu_a,mu_s))
plt.tight_layout()
plt.show()

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
ax.plot(pos[0],pos[1],pos[2])
plt.title('Trayectoria del fotón')
plt.show()


#Calculamos el promedio 

num_int = 50

def media_columnas_saltos_tres(matriz):
    medias_x = []
    medias_y = []
    medias_z = []
    # Iterar sobre las columnas
    for col in range(len(matriz[0])):
        elementos_columna_x = []
        elementos_columna_y = []
        elementos_columna_z = []
        # Iterar sobre las filas x con saltos de tres
        for fila_x in range(0, len(matriz), 3):
            if fila_x < len(matriz):
                elementos_columna_x.append(matriz[fila_x][col])
        # Iterar sobre las filas con saltos de tres
        for fila_y in range(1, len(matriz), 3):
            if fila_y < len(matriz):
                elementos_columna_y.append(matriz[fila_y][col])
        for fila_z in range(2, len(matriz), 3):
            if fila_z < len(matriz):
                elementos_columna_z.append(matriz[fila_z][col])
        # Calcular la media si hay elementos en la columna
        if elementos_columna_x:
            medias_x.append(np.mean(elementos_columna_x))
        if elementos_columna_y:
            medias_y.append(np.mean(elementos_columna_y))
        if elementos_columna_z:
            medias_z.append(np.mean(elementos_columna_z))
        
    return np.array([medias_x,medias_y,medias_z])


def mean_interaction(num_int):
    pos, _ = phot_traj(mu_t,mu_a,mu_s)
    for i in range(num_int):
        pos_new, _ = phot_traj(mu_t,mu_a,mu_s) 
        pos = np.vstack((pos, pos_new))
    
    mean_pos = media_columnas_saltos_tres(pos)
    return mean_pos


mean = mean_interaction(num_int)

fig1 = plt.figure()
ax = fig1.add_subplot(111, projection = '3d')
ax.plot(mean[0],mean[1],mean[2])
plt.title('Promedio interacciones $\\mu_a = {}$ $\\mu_s = {}$'.format(mu_a,mu_s))
plt.show()

# =============================================================================
# Integrando el código de la 2 en la práctica 1
# =============================================================================

# Parámetros
tau = 8 * 24 * 60   # Periodo de semidesintegración en minutos
T = 80 * 24 * 60  # Tiempo total de la simulación en minutos
dt = 180  # Paso de tiempo en minutos

# Inicialización de las listas para guardar los resultados
t = np.arange(0, T, dt)
N_I131 = np.zeros_like(t)
N_Xe131 = np.zeros_like(t) #Xenon-131 en el estado fundamental
N_Xe131_I = np.zeros_like(t) #Xenon-131 en el primer estado excitado
N_Xe131_II = np.zeros_like(t) #Xenon-131 en el segundo estado excitado
N_I131[0] = Natom

atoms = np.zeros_like(pos[:,0])
accel = 1
atoms_t = np.zeros([int(T/(dt*accel)),len(pos[:,0])])
energy = np.zeros_like(t)
traj_fot = []

for i in range(1,t.size):
    s = np.random.random(atoms.size)
    #Vemos si se desintegra o no
    
    indices_comunes = (atoms == 0) * (s < 1-2**(-dt/tau))
    atoms[indices_comunes] = 1
    
    #Vemos si es por el camino 1 o por el camino 2
    
    r = np.random.random(atoms.size)
    indices_comunes1 = (atoms == 1) * (r < 0.899)
    atoms[indices_comunes1] = 2
    energy[i-1] =  np.sum(atoms == 1) * 334 + np.sum([atoms == 2]) * 606
    N_Xe131_I[i-1] = np.sum(atoms == 2)
    N_Xe131_II[i-1] = np.sum(atoms == 1)
    
    
    atoms[np.where(atoms == 1)[0]],atoms[np.where(atoms == 2)[0]] = 3,3
    N_I131[i] = np.sum(atoms == 0)
    N_Xe131[i] = np.sum(atoms == 3)
    
    #Calculamos la trayectoria de todos los fotones emitidos (1 por cada átomo de Xenon que se forma)
    '''
    for j in range(N_Xe131[i]): #Hacer solo para tamaños pequeños de red, sino tarda mucho 
        traj_fot.append(phot_traj(mu_t,mu_a,mu_s)[0])
    ''' 
    
    if i%accel == 0:
        atoms_t[i] = atoms